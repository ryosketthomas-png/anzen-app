// ===================================================
// api.js - Google Sheets連携の共通モジュール
// 全HTMLページから読み込んで使用する
// ===================================================

// ⚠️ ここにGoogle Apps ScriptのデプロイURLを貼り付けてください
const GAS_URL = 'YOUR_GAS_DEPLOY_URL_HERE';

// ===================================================
// 共通送信関数
// ===================================================
async function postToSheets(sheetType, data) {
  try {
    const payload = { type: sheetType };
    Object.keys(data).forEach(k => { payload[k] = data[k]; });
    const res = await fetch(GAS_URL, {
      method: 'POST',
      body: JSON.stringify(payload)
    });
    const json = await res.json();
    if (json.status !== 'ok') throw new Error(json.message);
    return json.id;
  } catch(e) {
    console.error('Sheets送信エラー:', e);
    throw e;
  }
}

async function getFromSheets(type, params = {}) {
  try {
    const q = new URLSearchParams({ type, ...params }).toString();
    const res = await fetch(`${GAS_URL}?${q}`);
    const json = await res.json();
    if (json.status !== 'ok') throw new Error(json.message);
    return json.data;
  } catch(e) {
    console.error('Sheets取得エラー:', e);
    throw e;
  }
}

// ===================================================
// 各データの保存関数
// ===================================================

// 案件登録
async function saveAnken(formData) {
  return await postToSheets('anken', formData);
}

// 作業員登録（新規入場者）
async function saveWorker(formData) {
  return await postToSheets('worker', formData);
}

// 入退場記録
async function saveNyutaijo(formData) {
  // 「type」フィールドがGASのtype判定と競合するため「nyutaijoType」に変換して送る
  const payload = {
    ankenId: formData.ankenId,
    workerId: formData.workerId,
    name: formData.name,
    kaisha: formData.kaisha,
    shokushu: formData.shokushu,
    nyutaijoType: formData.type,
    time: formData.time,
    biko: formData.biko
  };
  return await postToSheets('nyutaijo', payload);
}

// 安全日誌
async function saveNisshi(formData) {
  return await postToSheets('nisshi', formData);
}

// ===================================================
// 各データの取得関数
// ===================================================

// 案件一覧取得
async function fetchAnkenList() {
  return await getFromSheets('anken');
}

// 作業員一覧取得（案件IDで絞り込み）
async function fetchWorkers(ankenId) {
  return await getFromSheets('workers', { ankenId });
}

// 入退場記録取得（案件ID・日付で絞り込み）
async function fetchNyutaijo(ankenId, date) {
  return await getFromSheets('nyutaijo', { ankenId, date });
}

// 安全日誌一覧取得
async function fetchNisshi(ankenId) {
  return await getFromSheets('nisshi', { ankenId });
}

// ===================================================
// プルダウン動的生成（案件・協力会社）
// ===================================================

// 案件一覧をキャッシュ付きで取得
let _ankenCache = null;
async function getAnkenCached() {
  if (_ankenCache) return _ankenCache;
  _ankenCache = await fetchAnkenList();
  return _ankenCache;
}

// 案件プルダウンをSheetsから生成
// 使い方: populateAnkenSelect('f-anken')
async function populateAnkenSelect(selectId) {
  const sel = document.getElementById(selectId);
  if (!sel) return;
  try {
    const list = await getAnkenCached();
    // 先頭のプレースホルダ以外を削除
    while (sel.options.length > 1) sel.remove(1);
    (list || []).forEach(a => {
      const name = a['工事名称'];
      if (!name) return;
      const opt = document.createElement('option');
      opt.value = name;
      opt.textContent = name;
      sel.appendChild(opt);
    });
  } catch(e) {
    console.warn('案件一覧の取得に失敗:', e);
  }
}

// 協力会社プルダウンを指定案件から生成
// 使い方: populateGyoshaSelect('f-gyosha', '淀屋橋ゲートタワー工事')
async function populateGyoshaSelect(selectId, kojimeiName) {
  const sel = document.getElementById(selectId);
  if (!sel) return;
  while (sel.options.length > 1) sel.remove(1);
  if (!kojimeiName) return;
  try {
    const list = await getAnkenCached();
    const anken = (list || []).find(a => String(a['工事名称'] || '').trim() === String(kojimeiName).trim());
    if (!anken) {
      console.warn('案件が見つかりません:', kojimeiName);
      return;
    }
    const kyoryoku = String(anken['協力会社'] || '').split('\n').map(s => s.trim()).filter(Boolean);
    if (kyoryoku.length === 0) {
      // 協力会社未登録の案件：分かるようにメッセージを表示
      const opt = document.createElement('option');
      opt.value = '';
      opt.textContent = '（この案件に協力会社が未登録です）';
      opt.disabled = true;
      sel.appendChild(opt);
      return;
    }
    kyoryoku.forEach(k => {
      const opt = document.createElement('option');
      opt.value = k;
      opt.textContent = k;
      sel.appendChild(opt);
    });
  } catch(e) {
    console.warn('協力会社の取得に失敗:', e);
  }
}

// ===================================================
// ユーティリティ
// ===================================================

// 送信中インジケーター表示
function showLoading(btn, text = '送信中...') {
  btn.disabled = true;
  btn._origText = btn.textContent;
  btn.textContent = text;
}

// 送信中インジケーター解除
function hideLoading(btn) {
  btn.disabled = false;
  btn.textContent = btn._origText || '送信';
}

// 今日の日付文字列（YYYY-MM-DD）
function todayStr() {
  const n = new Date();
  return `${n.getFullYear()}-${String(n.getMonth()+1).padStart(2,'0')}-${String(n.getDate()).padStart(2,'0')}`;
}

// 現在時刻文字列（HH:MM）
function nowTimeStr() {
  const n = new Date();
  return `${String(n.getHours()).padStart(2,'0')}:${String(n.getMinutes()).padStart(2,'0')}`;
}
